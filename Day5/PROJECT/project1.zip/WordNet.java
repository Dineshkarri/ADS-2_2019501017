import edu.princeton.cs.algs4.Bag;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.ST;
import java.util.ArrayList;

public class WordNet {
    private ST<String, Bag<Integer>> symbolTable = new ST<>();
    private ArrayList<String> nounList = new ArrayList<>();
    private Digraph dg;
    private SAP sap;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        check(synsets);
        check(hypernyms);
        In synsetsIn = new In(synsets);
        int V = 0;
        while (synsetsIn.hasNextLine()) {
            String[] syn = synsetsIn.readLine().split(",");
            int id = Integer.parseInt(syn[0]);
            String[] nouns = syn[1].split(" ");
            for (String noun : nouns) {
                if (symbolTable.contains(noun)) {
                    symbolTable.get(noun).add(id);
                } else {
                    Bag<Integer> bag = new Bag<Integer>();
                    bag.add(id);
                    symbolTable.put(noun, bag);
                }
            }
            V++;
            nounList.add(syn[1]);
        }
        dg = new Digraph(V);
        In hypernymsIn = new In(hypernyms);
        while (hypernymsIn.hasNextLine()) {
            String[] hyp = hypernymsIn.readLine().split(",");
            int childId = Integer.parseInt(hyp[0]);
            for (int i = 1; i < hyp.length; i++) {
                int parentId = Integer.parseInt(hyp[i]);
                dg.addEdge(childId, parentId);
            }
        }
        sap = new SAP(dg);
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return symbolTable.keys();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        check(word);
        return symbolTable.contains(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        check(nounA);
        check(nounB);
        Bag<Integer> start = symbolTable.get(nounA);
        Bag<Integer> end = symbolTable.get(nounB);
        return sap.length(start, end);
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        check(nounA);
        check(nounB);
        Bag<Integer> start = symbolTable.get(nounA);
        Bag<Integer> end = symbolTable.get(nounB);
        int ancestor = sap.ancestor(start, end);
        return nounList.get(ancestor);
    }

    private void check(Object obj) {
        if (obj == null) {
            throw new IllegalArgumentException();
        }
    }

    // do unit testing of this class
    public static void main(String[] args) {
        // WordNet wn = new WordNet("synsets3", "hypernyms3InvalidCycle");
    }
}
